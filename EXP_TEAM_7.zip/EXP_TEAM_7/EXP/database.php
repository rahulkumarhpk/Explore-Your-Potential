<?php
	$user = "root"; $pwd = ""; $host = "localhost"; $dbname = "exp";
?>